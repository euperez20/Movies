<nav>
    <ul>
        <li><a href="insert.php">Insert</a></li>
        <li><a href="select.php">Select</a></li>
        <li><a href="select_where.php">Select Where</a></li> 
        <li><a href="update.php">Update</a></li>        
    </ul>
</nav>
